$(document).ready(function () {
  var startBtn = document.getElementById("startbtn");
  var people = document.querySelectorAll(".human");
  var boards = document.querySelectorAll(".keyboard");
  var totalCount = people.length;

  startBtn.onclick = function () {
    startBtn.disabled = true; // 계속 클릭 못하게
    var i = 0;

    function showNext() {
      if (i >= totalCount) {
        return; // 끝나면 멈춤
      }

      // 사람 / 키보드 관련
      var p = people[i];
      var b = boards[i];

      // 나타나고 키보드 기울이기
      p.classList.add("show");
      b.classList.add("rotate");

      // 잠시 후 사람 사라지기
      setTimeout(function () {
        p.classList.add("fadeOut");

        p.addEventListener(
          "animationend",
          function () {
            p.classList.remove("show", "fadeOut");
            p.style.display = "none";
          },
          { once: true }
        );
      }, 1000);

      // 다음 넘어가기
      setTimeout(function () {
        i++;
        showNext();
      }, 1500);
    }

    showNext(); // 시작
  };
});
